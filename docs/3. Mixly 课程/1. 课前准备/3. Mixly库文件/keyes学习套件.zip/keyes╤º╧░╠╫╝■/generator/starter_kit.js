'use strict';

goog.provide('Blockly.Arduino.starter_kit');

goog.require('Blockly.Arduino');


 //////////////////LED灯////////////////
Blockly.Arduino.basic_led1 = function() {
  var dropdown_pin = Blockly.Arduino.valueToCode(this, 'PIN',Blockly.Arduino.ORDER_ATOMIC);
  var dropdown_stat = this.getFieldValue('STAT');
  Blockly.Arduino.setups_['setup_output_'+dropdown_pin] = 'pinMode('+dropdown_pin+', OUTPUT);';
  var code = 'digitalWrite('+dropdown_pin+','+dropdown_stat+');\n'
  return code;
};
Blockly.Arduino.basic_led2 = Blockly.Arduino.basic_led1

Blockly.Arduino.basic_led3 = Blockly.Arduino.basic_led1

Blockly.Arduino.basic_led4 = Blockly.Arduino.basic_led1

Blockly.Arduino.basic_a_Write = function() {
  var dropdown_pin = Blockly.Arduino.valueToCode(this, 'PIN',Blockly.Arduino.ORDER_ATOMIC);
  var value_num = Blockly.Arduino.valueToCode(this, 'NUM', Blockly.Arduino.ORDER_ATOMIC);
  Blockly.Arduino.setups_['setup_output_'+dropdown_pin] = 'pinMode('+dropdown_pin+', OUTPUT);';
  var code = 'analogWrite('+dropdown_pin+','+value_num+');\n'
  return code;
};
//////////////////////////RGB//////////////////////////////
  Blockly.Arduino.basic_rgb01 = function() {
  var dropdown_pin1 = Blockly.Arduino.valueToCode(this, 'R',Blockly.Arduino.ORDER_ATOMIC);
  var value_r = Blockly.Arduino.valueToCode(this, 'r', Blockly.Arduino.ORDER_ATOMIC);

  var dropdown_pin2 = Blockly.Arduino.valueToCode(this, 'G',Blockly.Arduino.ORDER_ATOMIC);
  var value_g = Blockly.Arduino.valueToCode(this, 'g', Blockly.Arduino.ORDER_ATOMIC);

  var dropdown_pin3 = Blockly.Arduino.valueToCode(this, 'B',Blockly.Arduino.ORDER_ATOMIC);
  var value_b = Blockly.Arduino.valueToCode(this, 'b', Blockly.Arduino.ORDER_ATOMIC);

  Blockly.Arduino.setups_['setup_output_'+dropdown_pin1] = 'pinMode('+dropdown_pin1+', OUTPUT);';
  Blockly.Arduino.setups_['setup_output_'+dropdown_pin2] = 'pinMode('+dropdown_pin2+', OUTPUT);';
  Blockly.Arduino.setups_['setup_output_'+dropdown_pin3] = 'pinMode('+dropdown_pin3+', OUTPUT);';
  
  var code = 'analogWrite('+dropdown_pin1+','+value_r+');\nanalogWrite('+dropdown_pin2+','+value_g+');\nanalogWrite('+dropdown_pin3+','+value_b+');\n';
  return code;
};

//////////////////////////有源蜂鸣器//////////////////////////////

Blockly.Arduino.basic_y_buzzer = function() {
  var dropdown_pin = Blockly.Arduino.valueToCode(this, 'PIN',Blockly.Arduino.ORDER_ATOMIC);
  var dropdown_stat = this.getFieldValue('STAT');
  Blockly.Arduino.setups_['setup_output_'+dropdown_pin] = 'pinMode('+dropdown_pin+', OUTPUT);';
  var code = 'digitalWrite('+dropdown_pin+','+dropdown_stat+');\n'
  return code;
};
//////////////////////////无源蜂鸣器//////////////////////////////
Blockly.Arduino.basic_w_buzzer1 = function() {
  var dropdown_pin = Blockly.Arduino.valueToCode(this, 'PIN',Blockly.Arduino.ORDER_ATOMIC);
  var dropdown_stat = this.getFieldValue('STAT');
  Blockly.Arduino.setups_['setup_output_'+dropdown_pin] = 'pinMode('+dropdown_pin+', OUTPUT);';
  var code = 'digitalWrite('+dropdown_pin+','+dropdown_stat+');\n'
  return code;
};

Blockly.Arduino.basic_w_buzzer2=function(){
   var dropdown_pin = Blockly.Arduino.valueToCode(this, 'PIN',Blockly.Arduino.ORDER_ATOMIC);
   var fre = Blockly.Arduino.valueToCode(this, 'FREQUENCY',
      Blockly.Arduino.ORDER_ASSIGNMENT) || '0';
   var code="tone("+dropdown_pin+","+fre+");\n";
   Blockly.Arduino.setups_['setup_output_'+dropdown_pin] = 'pinMode('+dropdown_pin+', OUTPUT);';
   return code;
};

Blockly.Arduino.basic_w_buzzer3=function(){
   var dropdown_pin = Blockly.Arduino.valueToCode(this, 'PIN',Blockly.Arduino.ORDER_ATOMIC);
   var fre = Blockly.Arduino.valueToCode(this, 'FREQUENCY',
      Blockly.Arduino.ORDER_ASSIGNMENT) || '0';
   var dur = Blockly.Arduino.valueToCode(this, 'DURATION',
      Blockly.Arduino.ORDER_ASSIGNMENT) || '0';
   var code="tone("+dropdown_pin+","+fre+","+dur+");\n";
   Blockly.Arduino.setups_['setup_output_'+dropdown_pin] = 'pinMode('+dropdown_pin+', OUTPUT);';
   return code;
};

//////////////////////////电机//////////////////////////////
Blockly.Arduino.basic_motor = function() {
  var dropdown_pin = Blockly.Arduino.valueToCode(this, 'PIN',Blockly.Arduino.ORDER_ATOMIC);
  var dropdown_stat = this.getFieldValue('STAT');
  Blockly.Arduino.setups_['setup_output_'+dropdown_pin] = 'pinMode('+dropdown_pin+', OUTPUT);';
  var code = 'digitalWrite('+dropdown_pin+','+dropdown_stat+');\n'
  return code;
};

//////////////////////////步进电机//////////////////////////////
Blockly.Arduino.basic_stepper = function() {
  var IN1 = Blockly.Arduino.valueToCode(this, 'PIN1',Blockly.Arduino.ORDER_ATOMIC);
  var IN2 = Blockly.Arduino.valueToCode(this, 'PIN2',Blockly.Arduino.ORDER_ATOMIC);
  var IN3 = Blockly.Arduino.valueToCode(this, 'PIN3',Blockly.Arduino.ORDER_ATOMIC);
  var IN4 = Blockly.Arduino.valueToCode(this, 'PIN4',Blockly.Arduino.ORDER_ATOMIC);

  var steps_val = Blockly.Arduino.valueToCode(this, 'steps_val',
      Blockly.Arduino.ORDER_ASSIGNMENT) || '0';
  var speed = Blockly.Arduino.valueToCode(this, 'speed_val',
      Blockly.Arduino.ORDER_ASSIGNMENT) || '0';

  Blockly.Arduino.definitions_['1stepper'] = '#include <Stepper.h>\nStepper mystepper('+steps_val+','+IN1+','+IN3+','+IN2+','+IN4+');\n';

  Blockly.Arduino.setups_['setup_stepper'] = 'mystepper.setSpeed('+speed+');\n';
  return '';
};

Blockly.Arduino.basic_stepper_steps = function() {
  var steps = Blockly.Arduino.valueToCode(this, 'steps',
      Blockly.Arduino.ORDER_ASSIGNMENT) || '0';
  return 'mystepper.step('+steps+');\n';
};

//////////////////////////数字传感器////////////////////////////////

Blockly.Arduino.basic_button = function() {
  var dropdown_pin = Blockly.Arduino.valueToCode(this, 'PIN',Blockly.Arduino.ORDER_ATOMIC);
  Blockly.Arduino.setups_['setup_input_'+dropdown_pin] = 'pinMode('+dropdown_pin+', INPUT);';
  var code = 'digitalRead('+dropdown_pin+')';
  return [code, Blockly.Arduino.ORDER_ATOMIC];
};
/////////////////火焰传感器////////////////
Blockly.Arduino.basic_flame = Blockly.Arduino.basic_button

/////////////////倾斜传感器////////////////
Blockly.Arduino.basic_tilt = Blockly.Arduino.basic_button


//////////////////////模拟传感器/////////////////////////

Blockly.Arduino.basic_light = function() {
  var dropdown_pin = Blockly.Arduino.valueToCode(this, 'PIN',Blockly.Arduino.ORDER_ATOMIC);
  Blockly.Arduino.setups_['setup_input_'+dropdown_pin] = 'pinMode('+dropdown_pin+', INPUT);';
  var code = 'analogRead('+dropdown_pin+')';
  return [code, Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino.basic_analog_t = Blockly.Arduino.basic_light;

Blockly.Arduino.basic_potentiometer = Blockly.Arduino.basic_light;


//////////////////////////显示屏///////////////////



///////////////////////////1位数码管/////////////////
Blockly.Arduino.basic_seg1=function(){
  var num = Blockly.Arduino.valueToCode(this, 'num', Blockly.Arduino.ORDER_ATOMIC);

  Blockly.Arduino.definitions_['abc'] = 'int a=7,b=6,c=5,d=10,e=11,f=8,g=9,dp=4;';
  Blockly.Arduino.definitions_['val3'] = 'int val='+num+';';

  Blockly.Arduino.definitions_['digital_0'] = 'void digital_0(void)\n{\nunsigned char j;\ndigitalWrite(a,HIGH);\ndigitalWrite(b,HIGH);\ndigitalWrite(c,HIGH);\ndigitalWrite(d,HIGH);\ndigitalWrite(e,HIGH);\ndigitalWrite(f,HIGH);\ndigitalWrite(g,LOW);\ndigitalWrite(dp,LOW);\n}\n';

  Blockly.Arduino.definitions_['digital_1'] = 'void digital_1(void)\n{\nunsigned char j;\ndigitalWrite(c,HIGH);\ndigitalWrite(b,HIGH);\nfor(j=7;j<=11;j++)\ndigitalWrite(j,LOW);\ndigitalWrite(dp,LOW);\n}\n';
  Blockly.Arduino.definitions_['digital_2'] = 'void digital_2(void)\n{\nunsigned char j;\ndigitalWrite(b,HIGH);\ndigitalWrite(a,HIGH);\nfor(j=9;j<=11;j++)\ndigitalWrite(j,HIGH);\ndigitalWrite(dp,LOW);\ndigitalWrite(c,LOW);\ndigitalWrite(f,LOW);\n}\n';
  Blockly.Arduino.definitions_['digital_3'] = 'void digital_3(void)\n{digitalWrite(g,HIGH);\ndigitalWrite(a,HIGH);\ndigitalWrite(b,HIGH);\ndigitalWrite(c,HIGH);\ndigitalWrite(d,HIGH);\ndigitalWrite(dp,LOW);\ndigitalWrite(f,LOW);\ndigitalWrite(e,LOW);\n}\n';
  Blockly.Arduino.definitions_['digital_4'] = 'void digital_4(void) \n{digitalWrite(c,HIGH);\ndigitalWrite(b,HIGH);\ndigitalWrite(f,HIGH);\ndigitalWrite(g,HIGH);\ndigitalWrite(dp,LOW);\ndigitalWrite(a,LOW);\ndigitalWrite(e,LOW);\ndigitalWrite(d,LOW);\n}\n';
  Blockly.Arduino.definitions_['digital_5'] = 'void digital_5(void)\n{\nunsigned char j;\ndigitalWrite(a,HIGH);\ndigitalWrite(b, LOW);\ndigitalWrite(c,HIGH);\ndigitalWrite(d,HIGH);\ndigitalWrite(e, LOW);\ndigitalWrite(f,HIGH);\ndigitalWrite(g,HIGH);\ndigitalWrite(dp,LOW);\n}\n';
  Blockly.Arduino.definitions_['digital_6'] = 'void digital_6(void) \n{\nunsigned char j;\nfor(j=7;j<=11;j++)\ndigitalWrite(j,HIGH);\ndigitalWrite(c,HIGH);\ndigitalWrite(dp,LOW);\ndigitalWrite(b,LOW);\n}\n';
  Blockly.Arduino.definitions_['digital_7'] = 'void digital_7(void)\n{\nunsigned char j;\nfor(j=5;j<=7;j++)\ndigitalWrite(j,HIGH);\ndigitalWrite(dp,LOW);\nfor(j=8;j<=11;j++)\ndigitalWrite(j,LOW);\n}\n';
  Blockly.Arduino.definitions_['digital_8'] = 'void digital_8(void)\n{\nunsigned char j;\nfor(j=5;j<=11;j++)\ndigitalWrite(j,HIGH);\ndigitalWrite(dp,LOW);\n}\n';
  Blockly.Arduino.definitions_['digital_9'] = 'void digital_9(void)\n{\nunsigned char j;\ndigitalWrite(a,HIGH);\ndigitalWrite(b,HIGH);\ndigitalWrite(c,HIGH);\ndigitalWrite(d,HIGH);\ndigitalWrite(e, LOW);\ndigitalWrite(f,HIGH);\ndigitalWrite(g,HIGH);\ndigitalWrite(dp,LOW);\n}\n';

   Blockly.Arduino.setups_['setup_input'] ='int i;\nfor(i=4;i<=11;i++)\npinMode(i,OUTPUT);\n';
  
  var code = 'switch(val)\n  {\n    case 0:digital_0();break;\n    case 1:digital_1();break;\n    case 2:digital_2();break;\n    case 3:digital_3();break;\n    case 4:digital_4();break;\n    case 5:digital_5();break;\n    case 6:digital_6();break;\n    case 7:digital_7();break;\n    case 8:digital_8();break;\n   case 9:digital_9();break;\n  }\n';
  return code;
};

///////////////////////////4位数码管/////////////////
Blockly.Arduino.basic_seg4=function(){
  var num = Blockly.Arduino.valueToCode(this, 'num', Blockly.Arduino.ORDER_ATOMIC);
  //var tc = Blockly.Arduino.valueToCode(this, 'tc', Blockly.Arduino.ORDER_ATOMIC);
  Blockly.Arduino.definitions_['1include_SevSeg-master'] = '#include "SevSeg.h"';
  Blockly.Arduino.definitions_['1sevseg'] = 'SevSeg sevseg;';
  Blockly.Arduino.definitions_['1val4'] = 'int val='+num+';';
  Blockly.Arduino.definitions_['1numDigits'] = 'byte numDigits = 4;';
  Blockly.Arduino.definitions_['1digitPins'] = 'byte digitPins[] = {2, 3, 4, 5};';
  Blockly.Arduino.definitions_['1segmentPins'] = 'byte segmentPins[] = {6, 7, 8, 9, 10, 11, 12, 13};';
  Blockly.Arduino.definitions_['1hardwareConfig'] = 'byte hardwareConfig = COMMON_CATHODE ; ';

  Blockly.Arduino.setups_['setup_input'] ='sevseg.begin(hardwareConfig, numDigits, digitPins, segmentPins);\n';

  var code = 'sevseg.setNumber('+num+', -1); \nsevseg.refreshDisplay();\n';
  return code;
};



////////////////////////1602LCD///////////////////////////
Blockly.Arduino.basic_1602lcd = function() {
  var str1 = Blockly.Arduino.valueToCode(this, 'TEXT1', Blockly.Arduino.ORDER_ATOMIC) || 'String(\"\")'
  var str2 = Blockly.Arduino.valueToCode(this, 'TEXT2', Blockly.Arduino.ORDER_ATOMIC) || 'String(\"\")'


  Blockly.Arduino.definitions_['1DRE'] = 'int DI = 12,RW = 11,Enable = 2;';
  Blockly.Arduino.definitions_['1DB'] = 'int DB[] = {3, 4, 5, 6, 7, 8, 9, 10};';
  Blockly.Arduino.definitions_['1STR'] = 'char *string = "0";';
  Blockly.Arduino.definitions_['1LcdCommandWrite'] = 'void LcdCommandWrite(int value) \n{\nint i = 0;\nfor (i=DB[0]; i <= DI; i++) \n{\ndigitalWrite(i,value & 01);\nvalue >>= 1;\n}\ndigitalWrite(Enable,LOW);\ndelayMicroseconds(1);\ndigitalWrite(Enable,HIGH);\ndelayMicroseconds(1); \ndigitalWrite(Enable,LOW);\ndelayMicroseconds(1); \n}\n';
  Blockly.Arduino.definitions_['1LcdDataWrite'] = 'void LcdDataWrite(int value) \n{\nint i = 0;\ndigitalWrite(DI, HIGH); \ndigitalWrite(RW, LOW); \nfor (i=DB[0]; i <= DB[7]; i++) \n{\ndigitalWrite(i,value & 01);\nvalue >>= 1;\n}\ndigitalWrite(Enable,LOW);  \ndelayMicroseconds(1);\ndigitalWrite(Enable,HIGH); \ndelayMicroseconds(1);\ndigitalWrite(Enable,LOW); \ndelayMicroseconds(1); \n}\n';
  //Blockly.Arduino.definitions_['LcdStringWrite'] = 'void LcdStringWrite(char *a)\n{\nfor(int i = 0;i < 14; i++)\n{\nif(*(a+i) == '\0')\n {\nbreak;\n}\nLcdDataWrite(*(a+i));\n}\n}\n';
   Blockly.Arduino.definitions_['1lsw'] = 'void LcdStringWrite(char *a)\n{\nfor(int i = 0;i < strlen(a); i++){\nLcdDataWrite(*(a+i));\n}\n}\n';

  Blockly.Arduino.setups_['setup_lcd'] = 'int i = 0;\nfor (i=Enable; i <= DI; i++) \n{\n    pinMode(i,OUTPUT);\n}\ndelay(100);\nLcdCommandWrite(0x38);\ndelay(64);  \nLcdCommandWrite(0x38); \ndelay(50);  \nLcdCommandWrite(0x38); \ndelay(20);  \nLcdCommandWrite(0x06); \ndelay(20);  \nLcdCommandWrite(0x0E);\ndelay(20);  \nLcdCommandWrite(0x01);  \ndelay(100); \nLcdCommandWrite(0x80); \ndelay(20);  \n';

  var code = 'LcdCommandWrite(0x01); \ndelay(10); \nLcdCommandWrite(0x80+0); \ndelay(10); \nstring = '+str1+';\nLcdStringWrite(string);\ndelay(10);\nLcdCommandWrite(0xc0+0); \n string = '+str2+';\nLcdStringWrite(string);\ndelay(10);\ndelay(300);';

  return code;
};

////////////////////////////////点阵////////////////////////////
Blockly.Arduino.basic_matrix_init = function() {
  Blockly.Arduino.definitions_[`onetube_var`] = 'int R[] = {2,3,4,5,6,7,8,9};\n'+
        'int C[] = {10,11,12,13,A0,A1,A2,A3};\n';

        Blockly.Arduino.definitions_[`1data_0`] = 
        'unsigned char data_0[8][8] =\n'+
        '{\n'+
        '{0,0,1,1,1,0,0,0},\n'+
        '{0,1,0,0,0,1,0,0},\n'+
        '{0,1,0,0,0,1,0,0},\n'+
        '{0,1,0,0,0,1,0,0},\n'+
        '{0,1,0,0,0,1,0,0},\n'+
        '{0,1,0,0,0,1,0,0},\n'+
        '{0,1,0,0,0,1,0,0},\n'+
        '{0,0,1,1,1,0,0,0}\n'+
        '};\n';

        Blockly.Arduino.definitions_[`1data_1`] = 
        'unsigned char data_1[8][8] =\n'+
        '{\n'+
        '{0,0,0,0,1,0,0,0},\n'+
        '{0,0,0,1,1,0,0,0},\n'+
        '{0,0,0,0,1,0,0,0},\n'+
        '{0,0,0,0,1,0,0,0},\n'+
        '{0,0,0,0,1,0,0,0},\n'+
        '{0,0,0,0,1,0,0,0},\n'+
        '{0,0,0,0,1,0,0,0},\n'+
        '{0,0,0,1,1,1,0,0}\n'+
        '};\n';

        Blockly.Arduino.definitions_[`1data_2`] = 
        'unsigned char data_2[8][8] =\n'+
        '{\n'+
        '{0,0,1,1,1,0,0,0},\n'+
        '{0,1,0,0,0,1,0,0},\n'+
        '{0,0,0,0,0,1,0,0},\n'+
        '{0,0,0,0,1,0,0,0},\n'+
        '{0,0,0,1,0,0,0,0},\n'+
        '{0,0,1,0,0,0,0,0},\n'+
        '{0,1,1,1,1,1,0,0},\n'+
        '{0,0,0,0,0,0,0,0}\n'+
        '};\n';

        Blockly.Arduino.definitions_[`1data_3`] = 
        'unsigned char data_3[8][8] =\n'+
        '{\n'+
        '{0,0,1,1,1,1,0,0},\n'+
        '{0,0,0,0,0,1,0,0},\n'+
        '{0,0,0,0,0,1,0,0},\n'+
        '{0,0,1,1,1,1,0,0},\n'+
        '{0,0,0,0,0,1,0,0},\n'+
        '{0,0,0,0,0,1,0,0},\n'+
        '{0,0,1,1,1,1,0,0},\n'+
        '{0,0,0,0,0,0,0,0}\n'+
        '};\n';

        Blockly.Arduino.definitions_[`1data_4`] = 
        'unsigned char data_4[8][8] =\n'+
        '{\n'+
        '{0,1,0,0,0,0,0,0},\n'+
        '{0,1,0,0,1,0,0,0},\n'+
        '{0,1,0,0,1,0,0,0},\n'+
        '{0,1,1,1,1,1,1,0},\n'+
        '{0,0,0,0,1,0,0,0},\n'+
        '{0,0,0,0,1,0,0,0},\n'+
        '{0,0,0,0,1,0,0,0},\n'+
        '{0,0,0,0,0,0,0,0}\n'+
        '};\n';

        Blockly.Arduino.definitions_[`1data_5`] = 
        'unsigned char data_5[8][8] =\n'+
        '{\n'+
        '{0,1,0,0,0,0,0,0},\n'+
        '{0,1,1,1,1,1,0,0},\n'+
        '{0,1,0,0,0,0,0,0},\n'+
        '{0,1,1,1,1,1,0,0},\n'+
        '{0,0,0,0,0,1,0,0},\n'+
        '{0,0,0,0,0,1,0,0},\n'+
        '{0,1,1,1,1,1,0,0},\n'+
        '{0,0,0,0,0,0,0,0}\n'+
        '};\n';

        Blockly.Arduino.definitions_[`1data_6`] = 
        'unsigned char data_6[8][8] =\n'+
        '{\n'+
        '{0,1,1,1,1,1,0,0},\n'+
        '{0,1,0,0,0,0,0,0},\n'+
        '{0,1,0,0,0,0,0,0},\n'+
        '{0,1,1,1,1,1,0,0},\n'+
        '{0,1,0,0,0,1,0,0},\n'+
        '{0,1,0,0,0,1,0,0},\n'+
        '{0,1,1,1,1,1,0,0},\n'+
        '{0,0,0,0,0,0,0,0}\n'+
        '};\n';

        Blockly.Arduino.definitions_[`1data_7`] = 
        'unsigned char data_7[8][8] =\n'+
        '{\n'+
        '{0,0,0,0,0,0,0,0},\n'+
        '{0,1,1,1,1,1,0,0},\n'+
        '{0,0,0,0,0,1,0,0},\n'+
        '{0,0,0,0,1,0,0,0},\n'+
        '{0,0,0,1,0,0,0,0},\n'+
        '{0,0,1,0,0,0,0,0},\n'+
        '{0,1,0,0,0,0,0,0},\n'+
        '{0,0,0,0,0,0,0,0}\n'+
        '};\n';

        Blockly.Arduino.definitions_[`1data_8`] = 
        'unsigned char data_8[8][8] =\n'+
        '{\n'+
        '{0,1,1,1,1,1,0,0},\n'+
        '{0,1,0,0,0,1,0,0},\n'+
        '{0,1,0,0,0,1,0,0},\n'+
        '{0,1,1,1,1,1,0,0},\n'+
        '{0,1,0,0,0,1,0,0},\n'+
        '{0,1,0,0,0,1,0,0},\n'+
        '{0,1,1,1,1,1,0,0},\n'+
        '{0,0,0,0,0,0,0,0}\n'+
        '};\n';

        Blockly.Arduino.definitions_[`1data_9`] = 
        'unsigned char data_9[8][8] =\n'+
        '{\n'+
        '{0,1,1,1,1,1,0,0},\n'+
        '{0,1,0,0,0,1,0,0},\n'+
        '{0,1,0,0,0,1,0,0},\n'+
        '{0,1,1,1,1,1,0,0},\n'+
        '{0,0,0,0,0,1,0,0},\n'+
        '{0,0,0,0,0,1,0,0},\n'+
        '{0,1,1,1,1,1,0,0},\n'+
        '{0,0,0,0,0,0,0,0}\n'+
        '};\n';

        Blockly.Arduino.definitions_[`matrix_pin_display`] = 
        'void Display(unsigned char dat[8][8])\n'+
        '{\n'+
        'for(int c = 0; c<8;c++)\n'+
        '{\n'+
        'digitalWrite(C[c],LOW);\n'+
        'for(int r = 0;r<8;r++)\n'+
        '{\n'+
        'digitalWrite(R[r],dat[r][c]);\n'+
        '}\n'+
        'delay(1);\n'+
        'Clear();\n'+
        '}\n'+
        '}\n';

        Blockly.Arduino.definitions_[`matrix_pin_clear`] = 
        'void Clear()\n'+
        '{\n'+
        'for(int i = 0;i<8;i++)\n'+
        '{\n'+
        'digitalWrite(R[i],LOW);\n'+
        'digitalWrite(C[i],HIGH);\n'+
        '}\n'+
        '}\n';

  Blockly.Arduino.setups_['setup_matrix'] = 'for(int i = 0;i<8;i++)\n  {\n    pinMode(R[i],OUTPUT);\n    pinMode(C[i],OUTPUT);\n  }\n';

  return '';
};

Blockly.Arduino.basic_matrix8 = function() {
  var matrix_data = Blockly.Arduino.valueToCode(this, 'num', Blockly.Arduino.ORDER_ATOMIC);

  return 'Display(data_'+matrix_data+');\n';
};

////////////////////////////////点阵1////////////////////////////
//执行器_点阵屏显示_显示图案
Blockly.Arduino.basic_matrix1 = function() {
  var dotMatrixArray = Blockly.Arduino.valueToCode(this, 'LEDArray', Blockly.Arduino.ORDER_ASSIGNMENT);

  return 'show_num(data_'+dotMatrixArray+');';
};
//执行器_点阵屏显示_点阵数组
Blockly.Arduino.basic_matrix2 = function() {
  var varName = this.getFieldValue('VAR');
  var a = new Array();
  for (var i = 1; i < 9; i++) {
    a[i] = new Array();
    for (var j = 1; j < 9; j++) {
      a[i][j] = (this.getFieldValue('a' + i + j) == "TRUE") ? 1 : 0;
    }
  }
  var code = '{';
  for (var i = 1; i < 9; i++) {
    var tmp = ""
    for (var j = 1; j < 9; j++) {
      tmp += a[i][j];
    }
    tmp = (parseInt(tmp, 2)).toString(16)
    if (tmp.length == 1) tmp = "0" + tmp;
    code += '0x' + tmp + ((i != 8) ? ',' : '');
  }
  code += '};';
  //Blockly.Arduino.definitions_[this.id] = "byte LedArray_"+clearString(this.id)+"[]="+code;
  Blockly.Arduino.definitions_[varName] = "unsigned char data_" + varName + "[8]=" + code;
  //return ["LedArray_"+clearString(this.id), Blockly.Arduino.ORDER_ATOMIC];
  return [varName, Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino.basic_matrix_clear = function() {

  return 'clear_();';
};


Blockly.Arduino.rc522_i2c_init = function() {
  Blockly.Arduino.definitions_['1include_rc522_iic_init'] = '#include <Wire.h>\n#include <MFRC522_I2C.h>\nMFRC522 mfrc522(0x28);\nString rfid_str = "";\n';
  Blockly.Arduino.definitions_['1include_rc522_iic_data'] = 'String return_rfid_data()\n'+
  '{\n'+
  '  if ( ! mfrc522.PICC_IsNewCardPresent() || ! mfrc522.PICC_ReadCardSerial() ) {\n'+
  '    delay(50);\n'+
  '    return "0";\n'+
  '  }\n'+
  '  rfid_str = "";\n'+
  '  for (byte i = 0; i < mfrc522.uid.size; i++) {\n'+
  '    rfid_str = rfid_str + String(mfrc522.uid.uidByte[i],HEX);\n'+
  '  }\n'+
  '  return rfid_str;\n'+
  '}\n';

  Blockly.Arduino.setups_['1setup_rc522_iic'] = 'Wire.begin();\nmfrc522.PCD_Init();\n';

  return '';
};


Blockly.Arduino.rc522_i2c_read = function () {
    return ['return_rfid_data()', Blockly.Arduino.ORDER_ATOMIC];
};

////////////////////////wifi///////////////////////////
Blockly.Arduino.wifi_init = function() {
  var ssid = Blockly.Arduino.valueToCode(this, 'TEXT1', Blockly.Arduino.ORDER_ATOMIC) || 'String(\"\")'
  var passwd = Blockly.Arduino.valueToCode(this, 'TEXT2', Blockly.Arduino.ORDER_ATOMIC) || 'String(\"\")'
  Blockly.Arduino.definitions_['wifi_init'] = '#include <ESP8266WiFi.h>\n#include <ESP8266mDNS.h>\n#include <WiFiClient.h>\n';
  Blockly.Arduino.definitions_['wifi'] = '#ifndef STASSID\n#define STASSID '+ssid+'\n#define STAPSK  '+passwd+'\n#endif\nconst char* ssid = STASSID;\nconst char* password = STAPSK;\nWiFiServer server(80);\nString unoData = "";\nint ip_flag = 0;\n';
  Blockly.Arduino.setups_['wifi_s'] = 'Serial.begin(9600);\n  WiFi.mode(WIFI_STA);\n'+
  '  WiFi.begin(ssid, password);\n'+
  '  while (WiFi.status() != WL_CONNECTED) {\n'+
  '    delay(500);\n'+
  '    Serial.print(".");\n'+
  '  }\n'+
  '  Serial.print("IP ADDRESS: ");\n'+
  '  Serial.println(WiFi.localIP());\n'+
  '  if (!MDNS.begin("esp8266")) {\n'+
  //'    Serial.println("Error setting up MDNS responder!");\n'+
  '    while (1) {\n'+
  '      delay(1000);\n'+
  '    }\n'+
  '  }\n'+
  //'  Serial.println("mDNS responder started");\n'+
  '  server.begin();\n'+
  //'  Serial.println("TCP server started");\n'+
  '  MDNS.addService("http", "tcp", 80);\n'+
  '  ip_flag = 1;\n';

  return '  if(ip_flag == 1)\n'+
  '  {\n'+
  '    Serial.print("IP: ");\n'+
  '    Serial.println(WiFi.localIP());\n'+
  '    delay(100);\n'+
  '  }\n'+
  '  MDNS.update();\n'+
  '  WiFiClient client = server.available();\n'+
  '  if (!client) {\n'+
  '    return;\n'+
  '  }\n'+
  '  while (client.connected() && !client.available()) {\n'+
  '    delay(1);\n'+
  '  }\n'+
  '  String req = client.readStringUntil(\'\\r\');\n'+
  '  int addr_start = req.indexOf(\' \');\n'+
  '  int addr_end = req.indexOf(\' \', addr_start + 1);\n'+
  '  if (addr_start == -1 || addr_end == -1) {\n'+
  //'    Serial.print("Invalid request: ");\n'+
  //'    Serial.println(req);\n'+
  '    return;\n'+
  '  }\n'+
  '  req = req.substring(addr_start + 1, addr_end);\n'+
  '  client.flush();\n'+
  '  String s;\n'+
  '  if (req == "/") {\n'+
  '    IPAddress ip = WiFi.localIP();\n'+
  '    String ipStr = String(ip[0]) + \'.\' + String(ip[1]) + \'.\' + String(ip[2]) + \'.\' + String(ip[3]);\n'+
  '    s = "HTTP/1.1 200 OK\\r\\nContent-Type: text/html\\r\\n\\r\\n<!DOCTYPE HTML>\\r\\n<html>Hello from ESP8266 at ";\n'+
  '    s += ipStr;\n'+
  '    s += "</html>\\r\\n\\r\\n";\n'+
  '    Serial.println(WiFi.localIP());\n'+
  '    Serial.write(\'*\');\n'+
  '      Serial.println(\'*\');\n'+
  '      client.print(WiFi.localIP());\n'+
  '      ip_flag = 0;\n'+
  '  }\n'+
  '  else if(req == "/btn/0")\n'+
  '  {\n'+
  '    Serial.write(\'a\');\n'+
  '    client.print("turn on the relay");\n'+
  '  }\n'+
  '  else if(req == "/btn/1")\n'+
  '  {\n'+
  '    Serial.write(\'b\');\n'+
  '    client.print("turn off the relay");\n'+
  '  }\n'+
  '  else if(req == "/btn/2")\n'+
  '  {\n'+
  '    Serial.write(\'c\');\n'+
  '    client.print("Bring the steering gear over 180 degrees");\n'+
  '  }\n'+
  '  else if(req == "/btn/3")\n'+
  '  {\n'+
  '    Serial.write(\'d\');\n'+
  '    client.print("Bring the steering gear over 0 degrees");\n'+
  '  }\n'+
  '  else if(req == "/btn/4")\n'+
  '  {\n'+
  '    Serial.write(\'e\');\n'+
  '    client.print("esp8266 already turn on the fans");\n'+
  '  }\n'+
  '  else if(req == "/btn/5")\n'+
  '  {\n'+
  '    Serial.write(\'f\');\n'+
  '    client.print("esp8266 already turn off the fans");\n'+
  '  }\n'+
  '  else if(req == "/btn/6")\n'+
  '  {\n'+
  '    Serial.write(\'g\');\n'+
  '    while(Serial.available() > 0)\n'+
  '    {\n'+
  '      unoData = Serial.readStringUntil(\'#\');\n'+
  '      client.println(unoData);\n'+
  '    }\n'+
  '  }\n'+
  '  else if(req == "/btn/7")\n'+
  '  {\n'+
  '    Serial.write(\'h\');\n'+
  '    client.println("turn off the ultrasonic");\n'+
  '  }\n'+
  '  else if(req == "/btn/8")\n'+
  '  {\n'+
  '    Serial.write(\'i\');\n'+
  '    while(Serial.available() > 0)\n'+
  '    {\n'+
  '      unoData = Serial.readStringUntil(\'#\');\n'+
  '      client.println(unoData);\n'+
  '    }\n'+
  '  }\n'+
  '  else if(req == "/btn/9")\n'+
  '  {\n'+
  '    Serial.write(\'j\');\n'+
  '    client.println("turn off the temperature");\n'+
  '  }\n'+
  '  else if(req == "/btn/10")\n'+
  '  {\n'+
  '    Serial.write(\'k\');\n'+
  '    while(Serial.available() > 0)\n'+
  '    {\n'+
  '      unoData = Serial.readStringUntil(\'#\');\n'+
  '      client.println(unoData);\n'+
  '    }\n'+
  '  }\n'+
  '  else if(req == "/btn/11")\n'+
  '  {\n'+
  '    Serial.write(\'l\');\n'+
  '    client.println("turn off the humidity");\n'+
  '  }\n'+
  '  else if(req == "/btn/12")\n'+
  '  {\n'+
  '    Serial.write(\'m\');\n'+
  '    client.print("esp8266 already turn on the LED");\n'+
  '  }\n'+
  '  else if(req == "/btn/13")\n'+
  '  {\n'+
  '    Serial.write(\'n\');\n'+
  '    client.print("esp8266 already turn off the LED");\n'+
  '  }\n'+
  '  else if(req == "/btn/14")\n'+
  '  {\n'+
  '    Serial.write(\'o\');\n'+
  '    client.print("esp8266 already turn on the LED");\n'+
  '  }\n'+
  '  else if(req == "/btn/15")\n'+
  '  {\n'+
  '    Serial.write(\'p\');\n'+
  '    client.print("esp8266 already turn off the LED");\n'+
  '  }\n'+
  '  else if(req == "/btn/16")\n'+
  '  {\n'+
  '    Serial.write(\'q\');\n'+
  '    client.print("esp8266 already turn on the LED");\n'+
  '  }\n'+
  '  else if(req == "/btn/17")\n'+
  '  {\n'+
  '    Serial.write(\'r\');\n'+
  '    client.print("esp8266 already turn off the LED");\n'+
  '  }\n'+
  '  else if(req == "/btn/18")\n'+
  '  {\n'+
  '    Serial.write(\'s\');\n'+
  '    client.print("esp8266 already turn on the LED");\n'+
  '  }\n'+
  '  else if(req == "/btn/19")\n'+
  '  {\n'+
  '    Serial.write(\'t\');\n'+
  '    client.print("esp8266 already turn off the LED");\n'+
  '  }\n'+
  '  else if(req == "/btn/20")\n'+
  '  {\n'+
  '    Serial.write(\'u\');\n'+
  '    client.print("esp8266 already turn on the LED");\n'+
  '  }\n'+
  '  else if(req == "/btn/21")\n'+
  '  {\n'+
  '    Serial.write(\'v\');\n'+
  '    client.print("esp8266 already turn off the LED");\n'+
  '  }\n'+
  '  else if(req == "/btn/22")\n'+
  '  {\n'+
  '    Serial.write(\'w\');\n'+
  '    client.print("esp8266 already turn on the LED");\n'+
  '  }\n'+
  '  else if(req == "/btn/23")\n'+
  '  {\n'+
  '    Serial.write(\'x\');\n'+
  '    client.print("esp8266 already turn off the LED");\n'+
  '  }\n'+
  '  else {\n'+
  //'    s = "HTTP/1.1 404 Not Found\\r\\n\\r\\n";\n'+
  //'    Serial.println("Sending 404");\n'+
  '  }\n'+
  '  client.print(F("IP : "));\n'+
  '  client.println(WiFi.localIP());\n';

};