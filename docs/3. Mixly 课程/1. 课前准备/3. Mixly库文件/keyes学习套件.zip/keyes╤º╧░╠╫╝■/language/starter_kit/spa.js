
Blockly.MIXLY_basic_LED1='Blue_LED';
Blockly.MIXLY_basic_LED2='Red_LED';
Blockly.MIXLY_basic_LED3='Yellow_LED';
Blockly.MIXLY_basic_LED4='Green_LED';
Blockly.MIXLY_basic_analog='analogWrite';
Blockly.MIXLY_basic_LED4 = 'LED Piranha amarilla';
Blockly.MIXLY_basic_LED5 = 'Blue Piranha LED';
Blockly.MIXLY_basic_LED01 = 'LED de tapa de paja';
Blockly.MIXLY_basic_LED02 = 'LED de tapa roja de paja';
Blockly.MIXLY_basic_LED03 = 'LED de tapa de paja verde';
Blockly.MIXLY_basic_LED04 = 'LED amarillo de tapa de paja';
Blockly.MIXLY_basic_LED05 = 'Blue Straw cap LED';
Blockly.MIXLY_basic_BUZZER1 = 'Buzzer activo';
Blockly.MIXLY_basic_BUZZER2 = 'Zumbador Pasivo';
Blockly.MIXLY_basic_RELAY = 'Relay';
Blockly.MIXLY_basic_MOTOR = 'Motor';
Blockly.MIXLY_basic_SERVO = 'servo';
Blockly.MIXLY_basic_2812RGB = 'Módulo 2812RGB';
Blockly.MIXLY_basic_stepper_init='Stepper init';
Blockly.MIXLY_basic_stepper_steps_val='Steps per revolution';
Blockly.MIXLY_basic_stepper_speed='speed';
Blockly.MIXLY_basic_stepper_name='Stepper';
Blockly.MIXLY_basic_stepper_steps='Operation steps';

Blockly.MIXLY_basic_IR_G = 'Módulo PIR';
Blockly.MIXLY_basic_FLAME = 'Sensor de llama';
Blockly.MIXLY_basic_HALL = 'Sensor Hall';
Blockly.MIXLY_basic_CRASH = 'Sensor de bloqueo';
Blockly.MIXLY_basic_BUTTON = 'Botón';
Blockly.MIXLY_basic_TUOCH = 'Touch capacitivo';
Blockly.MIXLY_basic_KNOCK = 'Knock Module';
Blockly.MIXLY_basic_TILT = 'Tilt Module';
Blockly.MIXLY_basic_SHAKE = 'Módulo de vibración';
Blockly.MIXLY_basic_REED_S = 'Módulo de conmutación de láminas';
Blockly.MIXLY_basic_TRACK = 'Módulo de seguimiento';
Blockly.MIXLY_basic_AVOID = 'Módulo de evitación de obstáculos';
Blockly.MIXLY_basic_LIGHT_B = 'Módulo de interrupción de luz';

Blockly.MIXLY_basic_ANALOG_T = 'Sensor de temperatura analógica';
Blockly.MIXLY_basic_SOUND = 'Sensor de sonido';
Blockly.MIXLY_basic_LIGHT = 'Sensor de luz';
Blockly.MIXLY_basic_WATER = 'Sensor de nivel de agua';
Blockly.MIXLY_basic_SOIL = 'Sensor de suelo';
Blockly.MIXLY_basic_POTENTIOMETER = 'potenciómetro';
Blockly.MIXLY_basic_LM35 = 'Sensor de temperatura LM35';
Blockly.MIXLY_basic_SLIDE_POTENTIOMETER = 'deslizar el potenciómetro';
Blockly.MIXLY_basic_TEMT6000 = 'Luz ambiente TEMT6000';
Blockly.MIXLY_basic_STEAM = 'sensor de vapor de agua';
Blockly.MIXLY_basic_FILM_P = 'Sensor de presión de película delgada';
Blockly.MIXLY_basic_JOYSTICK = 'Módulo de Joystick';
Blockly.MIXLY_basic_SMOKE = 'Sensor de humo';
Blockly.MIXLY_basic_ALCOHOL = 'Sensor de alcohol';
Blockly.MIXLY_basic_MQ135 = 'Calidad del aire MQ135';
Blockly.MIXLY_basic_18B20 = '18B20 Módulo de temperatura';
Blockly.MIXLY_basic_RT='temperatura';

Blockly.MIXLY_basic_DHT11 = 'módulo de temperatura y humedad';
Blockly.MIXLY_basic_BMP180 = 'Módulo de altímetro BMP180';
Blockly.MIXLY_basic_T='temperatura';
Blockly.MIXLY_basic_QY='Presión de aire';
Blockly.MIXLY_basic_H='altura';

Blockly.MIXLY_basic_SR01 = 'Módulo de Ultrasonido SR01';
Blockly.MIXLY_basic_3231 = '3231 reloj';
Blockly.MIXLY_basic_ADXL345 = 'Módulo de aceleración';
Blockly.MIXLY_basic_CARD1 = 'card1';
Blockly.MIXLY_basic_CARD2 = 'card2';

Blockly.MIXLY_basic_16button = '4*4button';

Blockly.MIXLY_basic_OLED = 'Módulo OLED';
Blockly.MIXLY_basic_1602LCD = 'IIC1602LCD';
Blockly.MIXLY_basic_2004LCD = 'IIC2004LCD';
Blockly.MIXLY_basic_MATRIX = '8 * 8 matriz de puntos';
Blockly.MIXLY_basic_TM1637 = 'LED Digital de 8 segmentos y 4 dígitos';
Blockly.MIXLY_basic_SMG='LED Digital de 8 segmentos y 1 dígitos';
Blockly.MIXLY_basic_ws='Dígitos';
Blockly.MIXLY_basic_begin='El bit de inicio';
Blockly.MIXLY_basic_fill0='complementario 0';
Blockly.MIXLY_basic_light='El brillo 0~7';
Blockly.MIXLY_basic_XY='Mostrar o esconder';
Blockly.MIXLY_basic_L='izquierda';
Blockly.MIXLY_basic_R='Derecho';
Blockly.MIXLY_basic_MH='dos puntos';
Blockly.MIXLY_basic_one='La primera línea';
Blockly.MIXLY_basic_two='Segunda línea';
Blockly.MIXLY_basic_three='Línea tres';
Blockly.MIXLY_basic_four='Línea cuatro';


Blockly.MIXLY_basic_value='valor numérico';


Blockly.MIXLY_basic_IR_E = 'Módulo transmisor de infrarrojos';
Blockly.MIXLY_basic_IR_R = 'Módulo receptor de infrarrojos';
Blockly.MIXLY_basic_W5100 = 'Módulo Ethernet W5100';
Blockly.MIXLY_basic_BLUETOOTH = 'Módulo Bluetooth 2.0';
Blockly.MIXLY_basic_rec='Carta recibida';

Blockly.MIXLY_basic_Count='La luz';

Blockly.MIXLY_basic_Matrix_init='Matrix 8*8 Init row:2~9 column:10~A3';
Blockly.MIXLY_basic_Matrix_custom='Visualización personalizada de la red de puntos';
Blockly.MIXLY_basic_Matrix_char='La matriz muestra UN solo carácter';
Blockly.MIXLY_basic_Matrix_dis='muestra';

Blockly.rc522_iic_init='RFID RC522_I2C Init';
Blockly.rc522_iic_read='RFID RC522_I2C Read';

Blockly.KS8266_passwd='Password';
Blockly.KS8266_ssid='ESP8266 connect the WiFi Name';