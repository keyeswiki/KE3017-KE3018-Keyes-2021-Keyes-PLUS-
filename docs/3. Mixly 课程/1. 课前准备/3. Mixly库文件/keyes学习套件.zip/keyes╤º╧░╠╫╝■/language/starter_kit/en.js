
Blockly.MIXLY_basic_LED1='Blue_LED';
Blockly.MIXLY_basic_LED2='Red_LED';
Blockly.MIXLY_basic_LED3='Yellow_LED';
Blockly.MIXLY_basic_LED4='Green_LED';
Blockly.MIXLY_basic_analog='analogWrite';
Blockly.MIXLY_basic_LED4='Yellow_LED';
Blockly.MIXLY_basic_LED5='Blue Piranha LED';
Blockly.MIXLY_basic_LED01='Straw cap LED';
Blockly.MIXLY_basic_LED02='Red Straw cap LED';
Blockly.MIXLY_basic_LED03='Green Straw cap LED';
Blockly.MIXLY_basic_LED04='Yellow straw cap LED';
Blockly.MIXLY_basic_LED05='Blue Straw cap LED';
Blockly.MIXLY_basic_BUZZER1='Active buzzer';
Blockly.MIXLY_basic_BUZZER2='Passive Buzzer';
Blockly.MIXLY_basic_RELAY='Relay';
Blockly.MIXLY_basic_MOTOR='Motor';
Blockly.MIXLY_basic_SERVO='servo';
Blockly.MIXLY_basic_2812RGB='2812RGB Module';
Blockly.MIXLY_basic_stepper_init='Stepper init';
Blockly.MIXLY_basic_stepper_steps_val='Steps per revolution';
Blockly.MIXLY_basic_stepper_speed='speed';
Blockly.MIXLY_basic_stepper_name='Stepper';
Blockly.MIXLY_basic_stepper_steps='Operation steps';

Blockly.MIXLY_basic_IR_G='PIR Module';
Blockly.MIXLY_basic_FLAME='Flame Sensor';
Blockly.MIXLY_basic_HALL='Hall Sensor';
Blockly.MIXLY_basic_CRASH='Crash Sensor';
Blockly.MIXLY_basic_BUTTON='Button switch';
Blockly.MIXLY_basic_TUOCH='Capacitive Touch';
Blockly.MIXLY_basic_KNOCK='Knock Module';
Blockly.MIXLY_basic_TILT='Tilt switch';
Blockly.MIXLY_basic_SHAKE='Vibration Module';
Blockly.MIXLY_basic_REED_S='Reed Switch Module';
Blockly.MIXLY_basic_TRACK='Tracking Module';
Blockly.MIXLY_basic_AVOID='Obstacle Avoidance Module';
Blockly.MIXLY_basic_LIGHT_B='Light Interrupt Module';

Blockly.MIXLY_basic_ANALOG_T='Analog Temperature Sensor';
Blockly.MIXLY_basic_SOUND='Sound Sensor';
Blockly.MIXLY_basic_LIGHT='Light Sensor';
Blockly.MIXLY_basic_WATER='Water Level Sensor';
Blockly.MIXLY_basic_SOIL='Soil Sensor';
Blockly.MIXLY_basic_POTENTIOMETER='potentiometer';
Blockly.MIXLY_basic_LM35='LM35 Temperature Sensor';
Blockly.MIXLY_basic_SLIDE_POTENTIOMETER='slide potentiometer';
Blockly.MIXLY_basic_TEMT6000='TEMT6000 Ambient Light';
Blockly.MIXLY_basic_STEAM='water vapor sensor';
Blockly.MIXLY_basic_FILM_P='Thin-film Pressure Sensor';
Blockly.MIXLY_basic_JOYSTICK='Joystick Module';
Blockly.MIXLY_basic_SMOKE='Smoke Sensor';
Blockly.MIXLY_basic_ALCOHOL='Alcohol Sensor';
Blockly.MIXLY_basic_MQ135='MQ135 Air Quality';
Blockly.MIXLY_basic_18B20='18B20 Temperature Module';
Blockly.MIXLY_basic_RT='temperature';

Blockly.MIXLY_basic_DHT11='temperature and humidity module';
Blockly.MIXLY_basic_BMP180='BMP180 altimeter module';
Blockly.MIXLY_basic_T='temperature';
Blockly.MIXLY_basic_QY='barometric pressure';
Blockly.MIXLY_basic_H='altitude';

Blockly.MIXLY_basic_SR01='SR01 Ultrasound Module';
Blockly.MIXLY_basic_3231='DS3231 clock';
Blockly.MIXLY_basic_ADXL345='Acceleration Module';

Blockly.MIXLY_basic_CARD1 = 'card1';
Blockly.MIXLY_basic_CARD2 = 'card2';

Blockly.MIXLY_basic_16button = '4*4button';


Blockly.MIXLY_basic_OLED='OLED Module';
Blockly.MIXLY_basic_1602LCD='IIC1602LCD';
Blockly.MIXLY_basic_2004LCD='IIC2004LCD';
Blockly.MIXLY_basic_MATRIX='8*8 dot matrix';
Blockly.MIXLY_basic_TM1637='4 digit 8-segment LED digital';
Blockly.MIXLY_basic_SMG='1 digit 8-segment LED digital';
Blockly.MIXLY_basic_ws='digit';
Blockly.MIXLY_basic_begin='Display position';
Blockly.MIXLY_basic_fill0='add 0?';
Blockly.MIXLY_basic_light='Brightness0~7';
Blockly.MIXLY_basic_XY='Show or hide';
Blockly.MIXLY_basic_L='left';
Blockly.MIXLY_basic_R='right';
Blockly.MIXLY_basic_MH='colon';
Blockly.MIXLY_basic_one='print line1';
Blockly.MIXLY_basic_two='print line2';
Blockly.MIXLY_basic_three='print line3';
Blockly.MIXLY_basic_four='print line4';


Blockly.MIXLY_basic_value='value';


Blockly.MIXLY_basic_IR_E='Infrared Transmitter Module';
Blockly.MIXLY_basic_IR_R='Infrared Receiver Module';
Blockly.MIXLY_basic_W5100='W5100 Ethernet Module';
Blockly.MIXLY_basic_BLUETOOTH='Bluetooth 2.0 Module';
Blockly.MIXLY_basic_rec='Received';


//Blockly.MIXLY_basic_kzsc = 'Control output';

Blockly.MIXLY_basic_Count='count';

Blockly.MIXLY_basic_Matrix_init='Matrix 8*8 Init row:2~9 column:10~A3';
Blockly.MIXLY_basic_Matrix_custom='Matrix custom display';
Blockly.MIXLY_basic_Matrix_char='Matrix Display a single character';
Blockly.MIXLY_basic_Matrix_dis='display';

Blockly.rc522_iic_init='RFID RC522_I2C Init';
Blockly.rc522_iic_read='RFID RC522_I2C Read';

Blockly.KS8266_passwd='Password';
Blockly.KS8266_ssid='ESP8266 connect the WiFi Name';